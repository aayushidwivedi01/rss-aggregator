package edu.upenn.cis455.storage;

import java.util.ArrayList;

import edu.upenn.cis455.xpathengine.PathNode;

public class XPath {

	private ArrayList<PathNode> xPath = new ArrayList<>();

	public XPath(ArrayList<PathNode> xPath) {
		this.xPath = xPath;
	}

}
